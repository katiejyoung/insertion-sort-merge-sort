# Insertion Sort and Merge Sort
Implement merge sort and insertion sort to sort an array/vector of integers.  Name your programs “mergesort” and “insertsort”.  Both programs should read inputs from a file called “data.txt” where the first value of each line is the number of integers that need to be sorted, followed by the integers.

## To Run the Code
1. Give yourself permission to the compiler using: "chmod 777 compileall".
2. Run "compileall" to compile the code.
3. To run insertsort, type "insertsort". To run mergesort, type "mergesort".